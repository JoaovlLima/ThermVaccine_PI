package com.thermvaccine.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import com.thermvaccine.model.RegistroDatalloger;
import com.thermvaccine.repository.RegistroRepository;

public class DataLoggerService {

    private final RegistroRepository registroRepository;

    public DataLoggerService(){
        this.registroRepository = new RegistroRepository();
    }

    public List<RegistroDatalloger> leituraArquivo() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        List<RegistroDatalloger> registros = new ArrayList<>();

        InputStream input = getClass()
                .getClassLoader()
                .getResourceAsStream("planilha_datalogger.csv");

        if (input == null) {
            throw new RuntimeException("Arquivo CSV não encontrado");
        }

        try (BufferedReader br = new BufferedReader(new InputStreamReader(input))) {
            String linha;
            br.readLine();

            while ((linha = br.readLine()) != null) {

                String[] valores = linha.split(";");

                LocalDateTime data_hora;
                try {
                    data_hora = LocalDateTime.parse(valores[1], formatter);
                } catch (DateTimeParseException e) {
                    data_hora = corrigirDataHora(valores[1]);
                }

                Long id = Long.parseLong(valores[0]);
                
                float t1 = Float.parseFloat(valores[2]);
                float t2 = Float.parseFloat(valores[3]);
                float temperatura = (t1+t2)/2;
                float energia = Float.parseFloat(valores[4]);
                boolean rede = Integer.parseInt(valores[5]) == 1;
                boolean alarme = Integer.parseInt(valores[7]) == 1;
                boolean compressor = Integer.parseInt(valores[8]) == 1;

                RegistroDatalloger registro = new RegistroDatalloger(id, temperatura, rede, energia, compressor,
                        alarme,data_hora);

                registros.add(registro);
                
            }
            // Indice;Data_Hora;T1_C;T2_C;Bateria_V;Rede;Porta;Alarme;Compressor;Status -> csv
            // id,temperatura,rede,energia,compressor,alarme,data_hora -> entidade
        } catch (IOException e) {
            e.printStackTrace();

        }

        return registros;
    }

    public LocalDateTime corrigirDataHora(String dataStr) {

    DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // separa data e hora
    String[] partesDataHora = dataStr.split(" ");

    String data = partesDataHora[0];
    String hora = partesDataHora[1];

    // separa HH:mm:ss
    String[] partesHora = hora.split(":");

    int horas = Integer.parseInt(partesHora[0]);
    int minutos = Integer.parseInt(partesHora[1]);
    int segundos = Integer.parseInt(partesHora[2]);


    String dataBase = data + " " +
            String.format("%02d:%02d:%02d", horas, minutos, 0);

    LocalDateTime dataHora =
            LocalDateTime.parse(dataBase, formatter);


    dataHora = dataHora.plusSeconds(segundos);

    return dataHora;
}


public void salvarRegistro(List<RegistroDatalloger> registros){

    for (RegistroDatalloger registro : registros) {

        List<RegistroDatalloger> registroBanco = registroRepository.listar();
        

        
        
    }

}

}

